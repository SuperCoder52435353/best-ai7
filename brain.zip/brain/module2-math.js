// module2-math.js
export function handleMath(text) {
  if (/^\d+[\+\-\*\/]\d+/.test(text)) {
    try {
      return `${text} = ${eval(text)}`;
    } catch {
      return "Iltimos, matematik ifodani to‘g‘ri yozing.";
    }
  }
  if (text.includes("kvadrat ildiz")) {
    const num = parseFloat(text.replace(/[^\d.]/g, ""));
    return !isNaN(num) ? `√${num} = ${Math.sqrt(num).toFixed(3)}` : null;
  }
  return null;
}
