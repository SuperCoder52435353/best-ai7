// brain.js - Bosh AI yo‘naltiruvchi
import { handleGreeting } from './module1-greeting.js';
import { handleMath } from './module2-math.js';
import { handleCode } from './module3-code.js';

export function getAIResponse(input) {
  const text = input.toLowerCase().trim();

  if (handleGreeting(text)) return handleGreeting(text);
  if (handleMath(text)) return handleMath(text);
  if (handleCode(text)) return handleCode(text);

  return "Bu savolga hozircha tayyor emasman. Yana urinib ko‘ring.";
}
import { handleBux } from './module4-bux.js';
import { handleBux } from './module4-bux.js';

export function getAIResponse(input) {
  const text = input.toLowerCase().trim();

  // 1. Buxgalteriya tekshirish
  const buxAnswer = handleBux(text);
  if (buxAnswer) return buxAnswer;

  // 2. Hech narsa topilmasa:
  return "Kechirasiz, savolingizni tushunmadim.";
}
