// module3-code.js
export function handleCode(text) {
  if (text.includes("html")) {
    return `<html><body><h1>Salom, dunyo!</h1></body></html>`;
  }
  if (text.includes("python")) {
    return `print("Salom, dunyo!")`;
  }
  if (text.includes("javascript")) {
    return `console.log("Salom, dunyo!");`;
  }
  return null;
}
