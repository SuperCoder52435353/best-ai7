// module4-bux.js - Buxgalteriya savollariga AI javoblari

export function handleBux(text) {
  if (text.includes("aktiv")) {
    return "Aktivlar — bu korxonaning mavjud boyliklari, ya'ni pul mablag'lari, tovarlar, binolar va h.k.";
  }

  if (text.includes("passiv")) {
    return "Passivlar — bu korxonaning majburiyatlari, qarzlari yoki kapitali.";
  }

  if (text.includes("balans")) {
    return "Balans — buxgalteriyada aktivlar va passivlarning tengligini ko‘rsatuvchi hujjat.";
  }

  if (text.includes("debet")) {
    return "Debet — buxgalteriya hisobida aktivning ko‘payishini bildiradi.";
  }

  if (text.includes("kredit")) {
    return "Kredit — buxgalteriyada passivning o‘sishini yoki aktivning kamayishini bildiradi.";
  }

  if (text.includes("amortizatsiya")) {
    return "Amortizatsiya — bu asosiy vositalarning foydalanish davomida qiymatining kamayishini bildiradi.";
  }

  if (text.includes("foyda")) {
    return "Foyda — bu tushumdan xarajatlar ayirilgandan keyin qolgan ijobiy farq.";
  }

  if (text.includes("soliq")) {
    return "Soliq — bu davlatga to‘lanadigan majburiy to‘lov.";
  }

  return null;
}
