// module1-greeting.js
export function handleGreeting(text) {
  if (/salom|hi|hello|how are you|assalomu/.test(text)) {
    return "Salom! Yordam bera olaman.";
  }
  if (/rahmat|thanks/.test(text)) {
    return "Doim tayyorman!";
  }
  return null;
}
